# Classic BuTube

Extensión para YouTube (Manifest V3) que:

- Cambia el **corazón** por el **👍 clásico** (con estado relleno al dar like).
- Recupera el **👎 No me gusta** en Shorts y muestra el **contador** (datos de [Return YouTube Dislike](https://returnyoutubedislike.com)).
- Idiomas: **ES, EN, PT** (automático según el navegador, o elegible en el popup).

## Abrir en VS Code

```bash
code classic-butube
npm install          # instala web-ext (opcional, para probar fácil)
npm run start:firefox
npm run start:chrome # Chrome / Edge / Brave / Opera (Chromium)
```

También hay tareas en `Terminal > Run Task`.

## Instalar a mano (sin npm)

| Navegador | Pasos |
|---|---|
| Chrome / Edge / Brave / Opera / Vivaldi | `chrome://extensions` → activar *Modo desarrollador* → *Cargar descomprimida* → elegir esta carpeta |
| Firefox (128+) | `about:debugging#/runtime/this-firefox` → *Cargar complemento temporal* → elegir `manifest.json` |
| Safari (macOS) | `xcrun safari-web-extension-converter ./classic-butube` y compilar el proyecto en Xcode |

Para publicar: `npm run build` genera el ZIP para Chrome Web Store, Edge Add-ons y Firefox AMO.

## Estructura

```
manifest.json
_locales/        nombre y descripción (en, es, pt_BR, pt_PT)
src/i18n.js      textos ES/EN/PT
src/content.js   cambia el icono, añade dislike y contador
src/content.css  estilos
src/main-world.js  llamada a la API interna de YouTube para el dislike
popup/           ajustes (toggles + idioma)
```

## Notas importantes

- YouTube cambia su HTML con frecuencia. Si algo deja de verse bien, los selectores
  están al inicio de `src/content.js` (`LIKE_SEL`, `DISLIKE_SEL`).
- En Shorts, YouTube eliminó el botón 👎 de su interfaz. El botón restaurado intenta
  enviar el dislike por la API interna de YouTube; **YouTube puede ignorarlo** si ya no
  lo procesa para Shorts. En videos normales el 👎 nativo sigue funcionando y la
  extensión solo añade el contador.
- Chrome muestra un aviso inofensivo por la clave `browser_specific_settings` (es para Firefox).
- Solo `www.youtube.com` (no incluye m.youtube.com ni la app móvil).
