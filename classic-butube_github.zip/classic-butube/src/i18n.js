(() => {
  'use strict';
  const D = {
    en: {
      tagline: 'The classic 👍, and 👎 is back.',
      enabled: 'Extension enabled',
      classic: 'Classic 👍 instead of the heart',
      dislikeBtn: 'Restore the Dislike button (Shorts)',
      dislikeCount: 'Show Dislike count',
      language: 'Language',
      auto: 'Automatic',
      dislike: 'Dislike',
      credit: 'Dislike data is estimated by Return YouTube Dislike.',
      hint: 'Changes apply instantly on YouTube.'
    },
    es: {
      tagline: 'El 👍 de siempre, y el 👎 está de vuelta.',
      enabled: 'Extensión activada',
      classic: '👍 clásico en lugar del corazón',
      dislikeBtn: 'Restaurar el botón No me gusta (Shorts)',
      dislikeCount: 'Mostrar contador de No me gusta',
      language: 'Idioma',
      auto: 'Automático',
      dislike: 'No me gusta',
      credit: 'Los datos de No me gusta son estimados por Return YouTube Dislike.',
      hint: 'Los cambios se aplican al instante en YouTube.'
    },
    pt: {
      tagline: 'O 👍 clássico, e o 👎 está de volta.',
      enabled: 'Extensão ativada',
      classic: '👍 clássico em vez do coração',
      dislikeBtn: 'Restaurar o botão Não gostei (Shorts)',
      dislikeCount: 'Mostrar contagem de Não gostei',
      language: 'Idioma',
      auto: 'Automático',
      dislike: 'Não gostei',
      credit: 'Os dados de Não gostei são estimados pelo Return YouTube Dislike.',
      hint: 'As mudanças são aplicadas na hora no YouTube.'
    }
  };
  const resolve = (setting) => {
    if (setting && setting !== 'auto' && D[setting]) return setting;
    const l = (navigator.language || 'en').slice(0, 2).toLowerCase();
    return D[l] ? l : 'en';
  };
  const t = (lang, key) => (D[lang] && D[lang][key]) || D.en[key] || key;
  globalThis.CBT_I18N = { D, resolve, t };
})();
