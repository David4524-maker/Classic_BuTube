// Runs in the PAGE context (world: MAIN) so it can read ytcfg and call YouTube's InnerTube API.
(() => {
  'use strict';
  if (window.__cbtMain) return;
  window.__cbtMain = true;

  const sha1 = async (s) => {
    const buf = await crypto.subtle.digest('SHA-1', new TextEncoder().encode(s));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  };
  const cookie = (name) => {
    const m = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  };

  async function rate(id, action) {
    const cfg = (k) => window.ytcfg && window.ytcfg.get && window.ytcfg.get(k);
    const context = cfg('INNERTUBE_CONTEXT');
    if (!context) throw new Error('ytcfg not ready');

    const headers = {
      'Content-Type': 'application/json',
      'X-Origin': location.origin,
      'X-Goog-AuthUser': String(cfg('SESSION_INDEX') || 0),
      'X-Youtube-Client-Name': String(cfg('INNERTUBE_CONTEXT_CLIENT_NAME') || 1),
      'X-Youtube-Client-Version': String(cfg('INNERTUBE_CONTEXT_CLIENT_VERSION') || '')
    };
    if (cfg('VISITOR_DATA')) headers['X-Goog-Visitor-Id'] = cfg('VISITOR_DATA');

    const sapisid = cookie('SAPISID') || cookie('__Secure-3PAPISID');
    if (sapisid) {
      const ts = Math.floor(Date.now() / 1000);
      headers.Authorization = `SAPISIDHASH ${ts}_${await sha1(`${ts} ${sapisid} ${location.origin}`)}`;
    }

    const key = cfg('INNERTUBE_API_KEY');
    const res = await fetch(`/youtubei/v1/like/${action}?prettyPrint=false${key ? '&key=' + key : ''}`, {
      method: 'POST',
      credentials: 'include',
      headers,
      body: JSON.stringify({ context, target: { videoId: id } })
    });
    return res.ok;
  }

  window.addEventListener('cbt:rate', async (e) => {
    let req;
    try { req = JSON.parse(e.detail); } catch { return; }
    let ok = false;
    try { ok = await rate(req.id, req.action); } catch (err) { /* ignore */ }
    window.dispatchEvent(new CustomEvent('cbt:rate-result', {
      detail: JSON.stringify({ reqId: req.reqId, ok })
    }));
  });
})();
