(() => {
  'use strict';
  if (window.top !== window) return;

  const api = globalThis.browser ?? globalThis.chrome;
  const I18N = globalThis.CBT_I18N;

  const DEFAULTS = { enabled: true, classicLike: true, dislikeButton: true, dislikeCount: true, lang: 'auto' };
  let settings = { ...DEFAULTS };
  let lang = 'en';

  // Material "thumb up" (filled) and "thumb up off" (outline) paths, 24x24.
  const P_ON = 'M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z';
  const P_OFF = 'M9 21h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2zM9 9l4.34-4.34L12 10h9v2l-3 7H9V9zM1 9h4v12H1z';
  const NS = 'http://www.w3.org/2000/svg';

  const makeSvg = (extra = '') => {
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('class', `cbt-svg ${extra}`.trim());
    svg.setAttribute('aria-hidden', 'true');
    for (const [d, cls] of [[P_OFF, 'cbt-p-off'], [P_ON, 'cbt-p-on']]) {
      const p = document.createElementNS(NS, 'path');
      p.setAttribute('d', d);
      p.setAttribute('class', cls);
      svg.appendChild(p);
    }
    return svg;
  };

  const t = (k) => I18N.t(lang, k);

  // ---------- Helpers ----------
  const getVideoId = () => {
    const m = location.pathname.match(/^\/shorts\/([\w-]{11})/);
    if (m) return m[1];
    if (location.pathname === '/watch') return new URLSearchParams(location.search).get('v');
    return null;
  };

  const fmt = (n) => {
    try {
      return new Intl.NumberFormat(lang, { notation: 'compact', maximumFractionDigits: 1 }).format(n);
    } catch { return String(n); }
  };

  // ---------- Dislike data (Return YouTube Dislike API) ----------
  const votesCache = new Map();
  const getVotes = (id) => {
    if (!votesCache.has(id)) {
      const p = fetch(`https://returnyoutubedislikeapi.com/votes?videoId=${id}`)
        .then((r) => (r.ok ? r.json() : null))
        .catch(() => null)
        .then((d) => {
          if (!d) setTimeout(() => votesCache.delete(id), 60000); // retry after 1 min
          return d;
        });
      votesCache.set(id, p);
    }
    return votesCache.get(id);
  };

  // ---------- 1) Swap the heart for the classic thumbs-up ----------
  const LIKE_SEL = [
    'like-button-view-model button',
    '#segmented-like-button button',
    'ytd-like-button-renderer #like-button button',
    'ytd-reel-player-overlay-renderer #like-button button'
  ].join(',');

  function swapLikeIcons() {
    document.querySelectorAll(LIKE_SEL).forEach((btn) => {
      if (btn.querySelector('.cbt-svg')) return;
      const icon = btn.querySelector('yt-icon, yt-icon-shape, lottie-component, svg');
      const host = btn.querySelector('.yt-spec-button-shape-next__icon') || (icon && icon.parentElement);
      if (!host || host === btn) return;
      host.classList.add('cbt-host');
      host.appendChild(makeSvg());
    });
  }

  // ---------- 2) Dislike count on buttons that already exist (watch page) ----------
  const DISLIKE_SEL = [
    'dislike-button-view-model button',
    '#segmented-dislike-button button',
    'ytd-reel-player-overlay-renderer #dislike-button button'
  ].join(',');

  function paintNativeDislike(votes) {
    document.querySelectorAll(DISLIKE_SEL).forEach((btn) => {
      if (btn.closest('ytd-reel-video-renderer:not([is-active])')) return;
      const native = btn.querySelector('.yt-spec-button-shape-next__button-text-content');
      if (native && native.textContent.trim() && !native.closest('.cbt-count')) return; // YouTube already shows one
      let span = btn.querySelector('.cbt-count');
      if (!span) {
        span = document.createElement('span');
        span.className = 'cbt-count';
        btn.appendChild(span);
        btn.classList.add('cbt-has-count');
      }
      const txt = votes ? fmt(votes.dislikes) : '';
      if (span.textContent !== txt) span.textContent = txt;
    });
  }

  // ---------- 3) Restore the Dislike button in Shorts ----------
  function rate(id, action) {
    return new Promise((resolve) => {
      const reqId = Math.random().toString(36).slice(2);
      const done = (ok) => { window.removeEventListener('cbt:rate-result', onRes); clearTimeout(timer); resolve(ok); };
      const onRes = (e) => {
        let d; try { d = JSON.parse(e.detail); } catch { return; }
        if (d.reqId === reqId) done(!!d.ok);
      };
      const timer = setTimeout(() => done(false), 8000);
      window.addEventListener('cbt:rate-result', onRes);
      window.dispatchEvent(new CustomEvent('cbt:rate', { detail: JSON.stringify({ id, action, reqId }) }));
    });
  }

  function buildDislike(id) {
    const wrap = document.createElement('div');
    wrap.className = 'cbt-dislike-btn';
    wrap.dataset.videoId = id;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'cbt-dislike-inner';
    btn.appendChild(makeSvg('cbt-svg--down'));

    const label = document.createElement('span');
    label.className = 'cbt-dlabel';

    wrap.append(btn, label);

    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const vid = wrap.dataset.videoId;
      if (!vid || wrap.classList.contains('cbt-busy')) return;
      const activating = !wrap.classList.contains('cbt-active');
      wrap.classList.add('cbt-busy');
      const ok = await rate(vid, activating ? 'dislike' : 'removelike');
      wrap.classList.remove('cbt-busy');
      if (ok) {
        wrap.classList.toggle('cbt-active', activating);
        btn.setAttribute('aria-pressed', String(activating));
      } else {
        wrap.classList.add('cbt-error');
        setTimeout(() => wrap.classList.remove('cbt-error'), 700);
      }
    });
    return wrap;
  }

  // Finds the element that sits in the Shorts action column (like / comments / share...)
  function likeAnchor(btn) {
    let el = btn.closest('#like-button') || btn.closest('like-button-view-model') || btn;
    while (el.parentElement && el.parentElement.children.length < 3 && !/^(BODY|HTML)$/.test(el.parentElement.tagName)) {
      el = el.parentElement;
    }
    return el;
  }

  const isVisible = (el) => {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };

  // Copy colors/size from the native like button so our button looks native in light AND dark themes.
  function matchStyle(wrap, likeBtn) {
    const cs = getComputedStyle(likeBtn);
    const r = likeBtn.getBoundingClientRect();
    const set = (k, v) => { if (v && wrap.style.getPropertyValue(k) !== v) wrap.style.setProperty(k, v); };
    set('--cbt-fg', cs.color);
    const bg = cs.backgroundColor;
    if (bg && bg !== 'transparent' && !/rgba\(\s*0,\s*0,\s*0,\s*0\s*\)/.test(bg)) set('--cbt-bg', bg);
    if (r.width >= 24 && r.width <= 96) set('--cbt-size', Math.round(r.width) + 'px');
  }

  function ensureShortsDislike() {
    const id = getVideoId();
    const mine = [...document.querySelectorAll('.cbt-dislike-btn')];
    if (!id || !location.pathname.startsWith('/shorts/')) { mine.forEach((m) => m.remove()); return; }

    // Like buttons currently on screen (the active Short); pick the one closest to the middle.
    const mid = window.innerHeight / 2;
    const cands = [...document.querySelectorAll(LIKE_SEL)]
      .map((b) => ({ b, r: b.getBoundingClientRect() }))
      .filter((x) => x.r.width > 0 && x.r.height > 0 && x.r.bottom > 0 && x.r.top < window.innerHeight)
      .sort((a, b) => Math.abs((a.r.top + a.r.bottom) / 2 - mid) - Math.abs((b.r.top + b.r.bottom) / 2 - mid));
    if (!cands.length) { mine.forEach((m) => m.remove()); return; }

    const anchor = likeAnchor(cands[0].b);
    const column = anchor.parentElement;
    if (!column) return;

    // If YouTube already shows a real dislike button in this column, don't add ours.
    const nativeDislike = [...column.querySelectorAll('#dislike-button, dislike-button-view-model')]
      .some((el) => !el.closest('.cbt-dislike-btn') && isVisible(el));
    if (nativeDislike) { mine.forEach((m) => m.remove()); return; }

    const existing = mine.find((m) => m.previousElementSibling === anchor);
    mine.forEach((m) => { if (m !== existing) m.remove(); });

    if (existing) {
      if (existing.dataset.videoId !== id) {
        existing.dataset.videoId = id;
        existing.classList.remove('cbt-active');
        existing.querySelector('button').removeAttribute('aria-pressed');
      }
      matchStyle(existing, cands[0].b);
      return;
    }
    const created = buildDislike(id);
    anchor.insertAdjacentElement('afterend', created);
    matchStyle(created, cands[0].b);
  }

  function paintCustomDislike(votes) {
    document.querySelectorAll('.cbt-dislike-btn').forEach((wrap) => {
      const btn = wrap.querySelector('button');
      const label = wrap.querySelector('.cbt-dlabel');
      const text = settings.dislikeCount && votes ? fmt(votes.dislikes) : t('dislike');
      if (label.textContent !== text) label.textContent = text;
      const title = t('dislike');
      if (btn.title !== title) { btn.title = title; btn.setAttribute('aria-label', title); }
    });
  }

  // ---------- Main loop ----------
  async function run() {
    swapLikeIcons();
    ensureShortsDislike();
    const id = getVideoId();
    if (!id) return;
    const votes = await getVotes(id);
    if (id !== getVideoId()) return;
    paintNativeDislike(votes);
    paintCustomDislike(votes);
  }

  let timer = null;
  const schedule = () => {
    if (timer) return;
    timer = setTimeout(() => { timer = null; run(); }, 120);
  };

  function applySettings() {
    lang = I18N.resolve(settings.lang);
    const root = document.documentElement;
    root.classList.toggle('cbt-on', settings.enabled);
    root.classList.toggle('cbt-classic', settings.enabled && settings.classicLike);
    root.classList.toggle('cbt-dislike', settings.enabled && settings.dislikeButton);
    root.classList.toggle('cbt-counts', settings.enabled && settings.dislikeCount);
    schedule();
  }

  async function init() {
    try {
      settings = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
    } catch { /* use defaults */ }
    applySettings();

    api.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      for (const [k, v] of Object.entries(changes)) settings[k] = v.newValue;
      applySettings();
    });

    new MutationObserver(schedule).observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['is-active']
    });
    window.addEventListener('yt-navigate-finish', schedule);
    window.addEventListener('scroll', schedule, { passive: true, capture: true });
    window.addEventListener('resize', schedule);
    setInterval(schedule, 1500);
    window.addEventListener('yt-page-data-updated', schedule);
    schedule();
  }

  init();
})();
