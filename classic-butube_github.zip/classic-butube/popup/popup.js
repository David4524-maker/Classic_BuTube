(() => {
  'use strict';
  const api = globalThis.browser ?? globalThis.chrome;
  const I18N = globalThis.CBT_I18N;
  const DEFAULTS = { enabled: true, classicLike: true, dislikeButton: true, dislikeCount: true, lang: 'auto' };
  const boolKeys = ['enabled', 'classicLike', 'dislikeButton', 'dislikeCount'];

  function translate(setting) {
    const lang = I18N.resolve(setting);
    document.documentElement.lang = lang;
    document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = I18N.t(lang, el.dataset.i18n); });
  }

  (async () => {
    const s = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
    boolKeys.forEach((k) => {
      const el = document.getElementById(k);
      el.checked = !!s[k];
      el.addEventListener('change', () => api.storage.local.set({ [k]: el.checked }));
    });
    const sel = document.getElementById('lang');
    sel.value = s.lang;
    translate(s.lang);
    sel.addEventListener('change', () => {
      api.storage.local.set({ lang: sel.value });
      translate(sel.value);
    });
  })();
})();
